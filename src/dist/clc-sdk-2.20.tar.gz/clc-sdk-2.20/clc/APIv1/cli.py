"""CLI console script entry point."""

import clc


def main():

	clc.v1.Args()
	clc.v1.ExecCommand()



