
import clc

class Group:

	@staticmethod
	def GetGroupID(alias,location,group):
		if alias is None:  alias = clc.Account.GetAlias()
		r = Group.GetGroups(alias,location)
		for row in r:
			if row['Name'] == group:  return(row['ID'])
		else:
			if clc.args:  clc.output.Status("ERROR",3,"Group %s not found in account %s datacenter %s" % (group,alias,location))
			raise Exception("Group not found")


	@staticmethod
	def NameGroups(data_arr,id_key):
		new_data_arr = []
		for data in data_arr:
			try:
				data_arr[id_key] = clc._GROUP_MAPPING[data[id_key]]
			except:
				pass
			new_data_arr.append(data)
		if clc.args:  clc.output.Status("ERROR",2,"Group name conversion not yet implemented")
		return(new_data_arr)


	@staticmethod
	def GetGroups(alias,location):
		if alias is None:  alias = clc.Account.GetAlias()
		r = clc.API.v1_call('post','Group/GetGroups',{'AccountAlias': alias, 'Location': location})
		for group in r['HardwareGroups']:  clc._GROUP_MAPPING[group['ID']] = group['Name']
		if int(r['StatusCode']) == 0:  return(r['HardwareGroups'])


	@staticmethod
	def Create(alias,location,parent,group,description=''):
		if alias is None:  alias = clc.Account.GetAlias()
		if description is None: description = ''
		# TODO - if no parent then assume default group "%s Hardware" % (locaiton)

		parents_id = Group.GetGroupID(alias,location,parent)

		r = clc.API.v1_call('post','Group/CreateHardwareGroup',
		                    {'AccountAlias': alias, 'ParentID': parents_id, 'Name': group, 'Description': description })
		if int(r['StatusCode']) == 0:  return(r['Group'])


	@staticmethod
	def Delete(alias,location,group):
		if alias is None:  alias = clc.Account.GetAlias()
		groups_id = Group.GetGroupID(alias,location,group)
		r = clc.API.v1_call('post','Group/DeleteHardwareGroup',{'AccountAlias': alias, 'ID': groups_id})
		if int(r['StatusCode']) == 0:  return(r)


	@staticmethod
	def Pause(alias,location,group):
		if alias is None:  alias = clc.Account.GetAlias()
		groups_id = Group.GetGroupID(alias,location,group)
		r = clc.API.v1_call('post','Group/PauseHardwareGroup',{'AccountAlias': alias, 'ID': groups_id})
		if int(r['StatusCode']) == 0:  return(r)


	@staticmethod
	def Poweron(alias,location,group):
		if alias is None:  alias = clc.Account.GetAlias()
		groups_id = Group.GetGroupID(alias,location,group)
		r = clc.API.v1_call('post','Group/PoweronHardwareGroup',{'AccountAlias': alias, 'ID': groups_id})
		if int(r['StatusCode']) == 0:  return(r)


	@staticmethod
	def Archive(alias,location,group):
		if alias is None:  alias = clc.Account.GetAlias()
		groups_id = Group.GetGroupID(alias,location,group)
		r = clc.API.v1_call('post','Group/ArchiveHardwareGroup',{'AccountAlias': alias, 'ID': groups_id})
		if int(r['StatusCode']) == 0:  return(r)


	# TODO - cannot find groups ID since not listed for archived groups
	#@staticmethod
	#def Restore(alias,location,group):
	#	if alias is None:  alias = clc.Account.GetAlias()
	#	groups_id = Group.GetGroupID(alias,location,group)
	#	r = clc.API.v1_call('post','Group/RestoreHardwareGroup',{'AccountAlias': alias, 'ID': groups_id})
	#	if int(r['StatusCode']) == 0:  return(r)



