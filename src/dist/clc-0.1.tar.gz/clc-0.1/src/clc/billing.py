
import clc

class Billing:


	@staticmethod
	def GetGroupEstimate(alias,location,group):
		if alias is None:  alias = clc.Account.GetAlias()
		groups_id = clc.Group.GetGroupID(alias,location,group)

		r = clc.API.v1_call('post','Billing/GetGroupEstimate',{'AccountAlias': alias, 'HardwareGroupID': groups_id})
		if int(r['StatusCode']) == 0:  
			return(r)


	# NOTE - This API isn't returing data as expected
	# NOTE - We aren't returning any of the server-level data here, just group
	@staticmethod
	def GetGroupSummaries(alias,date_start=None,date_end=None):
		if alias is None:  alias = clc.Account.GetAlias()
		payload = {'AccountAlias': alias}
		if date_start is not None:  payload['StartDate'] = date_start
		if date_end is not None:  payload['EndDate'] = date_end

		r = clc.API.v1_call('post','Billing/GetGroupSummaries',payload)
		if int(r['StatusCode']) == 0:  
			return(r['GroupTotals'])


	@staticmethod
	def GetServerEstimate(alias,server):
		if alias is None:  alias = clc.Account.GetAlias()
		r = clc.API.v1_call('post','Billing/GetServerEstimate',{'AccountAlias': alias, 'ServerName': server})
		if int(r['StatusCode']) == 0:  
			return(r)


	@staticmethod
	def GetAccountSummary(alias):
		if alias is None:  alias = clc.Account.GetAlias()
		r = clc.API.v1_call('post','Billing/GetAccountSummary',{'AccountAlias': alias})
		if int(r['StatusCode']) == 0:  
			return(r)



