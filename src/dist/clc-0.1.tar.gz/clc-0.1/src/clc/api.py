# -*- coding: utf-8 -*-

import requests
import xml.etree.ElementTree
import clc


class API():
	
	#def __init__(function):
	#	pass


	@staticmethod
	def _Login_v2():
		r = requests.post("%s%s" % (clc.defaults.ENDPOINT_URL_V2,"/authentication/login"), 
						  data={'username': clc._V2_API_USERNAME, 'password': clc._V2_API_PASSWD},
						  headers={'content-type': 'application/json'})

		if r.status_code == 200:
			clc._LOGIN_TOKEN_V2 = r.json()['bearerToken']
			clc._ALIAS = r.json()['accountAlias']
		elif r.status_code == 400:
			raise(Exception("Invalid V2 API login.  %s" % (r.json()['message'])))
		else:
			raise(Exception("Error logging into V2 API.  Response code %s. message %s" % (r.status_code,r.json()['message'])))


	@staticmethod
	def _Login_v1():
		clc._LOGINS += 1

		r = requests.post("%s%s" % (clc.defaults.ENDPOINT_URL_V1,"/Auth/logon"),
						  params={'APIKey': clc._V1_API_KEY, 'Password': clc._V1_API_PASSWD})

		try:
			resp = xml.etree.ElementTree.fromstring(r.text)
			if resp.attrib['StatusCode'] == '0':
				if clc.args:  clc.output.Status('SUCCESS',1,'Logged into v1 API')
				clc._LOGIN_COOKIE_V1 = r.cookies
			else:
				if clc.args:  clc.output.Status('ERROR',3,'Error logging into v1 API.  %s' % resp.attrib['Message'])
				raise(Exception("Error logging into V1 API.  Status code %s. %s" % (resp.attrib['StatusCode'],resp.attrib['Message'])))
		except:
			if clc.args:  clc.output.Status('ERROR',3,'Error logging into v1 API.  Server response %s' % (r.status_code))


	@staticmethod
	def v1_call(method,url,payload,silent=False,hide_errors=[],recursion_cnt=0):
		if not clc._LOGIN_COOKIE_V1:  clc.API._Login_v1()

		r = requests.request(method,"%s%s/JSON" % (clc.defaults.ENDPOINT_URL_V1,url), 
		                     params=payload, 
							 headers={'content-type': 'application/json'},
		                     cookies=clc._LOGIN_COOKIE_V1)

		try:
			if int(r.json()['StatusCode']) == 0:  
				if clc.args and not silent:  clc.output.Status('SUCCESS',2,'%s' % (r.json()['Message']))
				return(r.json())
			elif int(r.json()['StatusCode']) in hide_errors:
				return(r.json())
			elif int(r.json()['StatusCode']) == 2:  
				# Account is deleted
				raise clc.AccountDeletedException(r.json()['Message'])
			elif int(r.json()['StatusCode']) == 5:  
				# Account or datacenter does not exist
				raise clc.AccountDoesNotExistException(r.json()['Message'])
			elif int(r.json()['StatusCode']) == 100 and recursion_cnt<2:  
				# Not logged in - this is a transient failure
				clc._LOGIN_COOKIE_V1 = False
				return(clc.API.v1_call(method,url,payload,silent,hide_errors,recursion_cnt+1))
			elif int(r.json()['StatusCode']) == 100:  
				# Not logged in - this keeps recurring - bail
				raise clc.AccountLoginException(r.json()['Message'])
			else:
				if clc.args and (not hide_errors or not silent):  clc.output.Status('ERROR',3,'Error calling %s.   Status code %s.  %s' % (url,r.json()['StatusCode'],r.json()['Message']))
				raise Exception('Error calling %s.   Status code %s.  %s' % (url,r.json()['StatusCode'],r.json()['Message']))
		#except clc.AccountDeletedException, clc.AccountLoginException:
		except clc.CLCException:
			raise
		except:
			if clc.args and (not hide_errors or not silent):  clc.output.Status('ERROR',3,'Error calling %s.  Server response %s' % (url,r.status_code))
			#print "Request:  %s %s  params=%s" % (method,"%s%s/JSON" % (clc.defaults.ENDPOINT_URL_V1,url),payload)
			#print "Response: %s" % (r.text)
			#print r.url
			print url
			print payload
			print r.text
			raise Exception('Error calling %s.  Server response %s' % (url,r.status_code))


	@staticmethod
	def v2_call(method,url,payload):
		if not clc._LOGIN_TOKEN_V2:  clc.API._Login_v2()

		r = requests.request(method,"%s%s" % (clc.defaults.ENDPOINT_URL_V2,url), 
		                     params=payload, 
							 headers={'content-type': 'application/json', 'Bearer': clc._LOGIN_TOKEN_V2})

		try:
			if int(r.json()['StatusCode']) == 0:  
				if clc.args:  clc.output.Status('SUCCESS',2,'%s' % (r.json()['Message']))
				return(r.json())
			else:
				if clc.args:  clc.output.Status('ERROR',3,'Error calling %s.   Status code %s.  %s' % (url,r.json()['StatusCode'],r.json()['Message']))
				raise(Exception("Error calling %s.   Status code %s.  %s" % (url,r.json()['StatusCode'],r.json()['Message'])))
		except:
			raise
			if clc.args:  clc.output.Status('ERROR',3,'Error calling %s.  Server response %s' % (url,r.status_code))


