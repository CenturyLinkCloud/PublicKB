
import clc


def main():

	clc.Args()
	clc.ExecCommand()



