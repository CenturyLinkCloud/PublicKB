
import clc

class Queue:

	item_status_type_map = { 'All': 1, 'Pending': 2, 'Complete': 3, 'Error': 4 }


	@staticmethod
	def List(type='All'):
		r = clc.API.v1_call('post','Queue/ListQueueRequests',{'ItemStatusType': Queue.item_status_type_map[type] })
		if int(r['StatusCode']) == 0:  return(r['Requests'])


	@staticmethod
	def GetStatus(request_id,silent=False):
		r = clc.API.v1_call('post','Queue/GetRequestStatus',{'RequestID': request_id},silent=silent)
		if int(r['StatusCode']) == 0:  return(r['RequestDetails'])



