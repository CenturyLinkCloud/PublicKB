
import clc

class Server:

	@staticmethod
	def GetServerDetails(alias,servers):
		if alias is None:  alias = clc.Account.GetAlias()

		results = []
		for server in servers:
			r = clc.API.v1_call('post','Server/GetServer', {'AccountAlias': alias, 'Name': server })
			if int(r['StatusCode']) == 0:  results.append(r['Server'])

		return(results)
		#r = clc.API.v1_call('post','Server/GetServer', {'AccountAlias': alias, 'Name': server })
		#if int(r['StatusCode']) == 0:  return(r['Server'])


	@staticmethod
	def GetServers(alias,location,group,name_groups=False):
		if alias is None:  alias = clc.Account.GetAlias()
		payload = {'AccountAlias': alias }
		if group:  payload['HardwareGroupID'] = clc.Group.GetGroupID(alias,location,group)
		else:  payload['Location'] = location
		r = clc.API.v1_call('post','Server/GetAllServers', payload)
		if name_groups:  r['Servers'] = clc.Group.NameGroups(r['Servers'],'HardwareGroupID')
		if int(r['StatusCode']) == 0:  return(r['Servers'])


	@staticmethod
	def GetAllServers(alias=None,name_groups=False):
		if alias is None:  alias = clc.Account.GetAlias()
		servers = []
		clc.Account.GetLocations()
		for location in clc.LOCATIONS:
			try:
				r = clc.API.v1_call('post','Server/GetAllServers', {'AccountAlias': alias, 'Location': location }, hide_errors=[5,] )
				if name_groups:  r['Servers'] = clc.Group.NameGroups(r['Servers'],'HardwareGroupID')
				if int(r['StatusCode']) == 0:  servers += r['Servers']
			except:
				pass
		return(servers)


	@staticmethod
	def GetTemplates(alias=None,location=None):
		if alias is None:  alias = clc.Account.GetAlias()
		if location is None:  location = clc.Account.GetLocation()

		r = clc.API.v1_call('post','Server/ListAvailableServerTemplates', { 'AccountAlias': alias, 'Location': location } )
		return(r['Templates'])


	@staticmethod
	def Create(alias,location,name,template,cpu,ram,backup_level,group=None, group_id=None, network='',description='',password=''):
		if alias is None:  alias = clc.Account.GetAlias()
		if location is None:  location = clc.Account.GetLocation()
		if group is not None:  groups_id = clc.Group.GetGroupID(alias,location,group)

		r = clc.API.v1_call('post','Server/CreateServer',
		                    { 'AccountAlias': alias, 'LocationAlias': location, 'Description': description, 'Template': template,
							  'Alias': name, 'HardwareGroupID': groups_id, 'ServerType': 1, 'ServiceLevel': backup_level, 'Cpu': cpu,
							  'MemoryGB': ram, 'ExtraDriveGB': 0, 'Network': network, 'Password': password })
		if int(r['StatusCode']) == 0:  return(r)


	@staticmethod
	def Delete(alias,servers):
		if alias is None:  alias = clc.Account.GetAlias()
		results = []
		for server in servers:
			r = clc.API.v1_call('post','Server/DeleteServer', {'AccountAlias': alias, 'Name': server })
			if int(r['StatusCode']) == 0:  results.append(r)
		return(results)


	@staticmethod
	def GetCredentials(alias,servers):
		if alias is None:  alias = clc.Account.GetAlias()
		results = []
		for server in servers:
			r = clc.API.v1_call('post','Server/GetServerCredentials', {'AccountAlias': alias, 'Name': server })
			if int(r['StatusCode']) == 0:  results.append(r)
		return(results)


