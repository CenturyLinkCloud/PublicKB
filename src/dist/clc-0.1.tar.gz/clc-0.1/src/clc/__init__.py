# -*- coding: utf-8 -*-

from clc.client import Client
from clc.shell import Args, ExecCommand
from clc.account import Account
from clc.user import User
from clc.group import Group
from clc.server import Server
from clc.network import Network
from clc.billing import Billing
from clc.queue import Queue
from clc.blueprint import Blueprint
from clc.api import API


####### module/object vars #######
_V1_API_KEY = False
_V1_API_PASSWD = False
_V2_API_USERNAME = False
_V2_API_PASSWD = False

args = False

_LOGIN_COOKIE_V1 = False
_LOGIN_TOKEN_V2 = False

_LOGINS = 0
_ALIAS = False
_LOCATION = False
_BLUEPRINT_FTP_URL = False

_GROUP_MAPPING = {}

LOCATIONS = ['CA1','CA2','CA3','DE1','GB1','GB3','IL1','NY1','UC1','UT1','VA1','WA1']	# point in time snapshot - exec Account.GetLocations for current

class CLCException(Exception):
	pass
class AccountDoesNotExistException(CLCException):
	pass
class AccountDeletedException(CLCException):
	pass
class AccountLoginException(CLCException):
    pass

class output:
	
	@staticmethod
	def Status(status,level,message):
		pass


