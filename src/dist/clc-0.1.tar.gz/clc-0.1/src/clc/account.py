
import clc

class Account:

	@staticmethod
	def GetAlias():  
		if not clc._ALIAS:  Account.GetAccounts()
		return(clc._ALIAS)


	@staticmethod
	def GetLocation():  
		if not clc._LOCATION:  Account.GetAccounts()
		return(clc._LOCATION)


	@staticmethod
	def GetAccountDetails(alias):
		r = clc.API.v1_call('post','Account/GetAccountDetails',{'AccountAlias': alias})
		if r['Success'] != True: 
			if clc.args:  clc.output.Status('ERROR',3,'Error calling %s.   Status code %s.  %s' % ('Account/GetAccountDetails',r['StatusCode'],r['Message']))
			raise Exception('Error calling %s.   Status code %s.  %s' % ('Account/GetAccountDetails',r['StatusCode'],r['Message']))
		elif int(r['StatusCode']) == 0:  
			return(r['AccountDetails'])


	@staticmethod
	def GetLocations():
		r = clc.API.v1_call('post','Account/GetLocations',{})
		if r['Success'] != True: 
			if clc.args:  clc.output.Status('ERROR',3,'Error calling %s.   Status code %s.  %s' % ('Account/GetLocations',r['StatusCode'],r['Message']))
			raise Exception('Error calling %s.   Status code %s.  %s' % ('Account/GetLocations',r['StatusCode'],r['Message']))
		elif int(r['StatusCode']) == 0:  
			clc.LOCATIONS = [x['Alias'] for x in r['Locations']]
			return(r['Locations'])


	@staticmethod
	def GetAccounts(alias=None):
		if alias is not None:  payload = {'AccountAlias': alias}
		else:  payload = {}
		r = clc.API.v1_call('post','Account/GetAccounts',payload)
		if int(r['StatusCode']) == 0:  
			# Assume first response is always the original account.  Not sure if this is reliable
			if not clc._ALIAS:  clc._ALIAS = r['Accounts'][0]['AccountAlias']
			if not clc._LOCATION:  clc._LOCATION = r['Accounts'][0]['Location']

			return(r['Accounts'])



