
import clc

class User:

	@staticmethod
	def GetUserDetails(alias, user):
		if alias is None:  alias = clc.Account.GetAlias()
		r = clc.API.v1_call('post','User/GetUserDetails',{'AccountAlias': alias, 'UserName': user })
		if int(r['StatusCode']) == 0:  
			return(r['UserDetails'])


	@staticmethod
	def GetUsers(alias):
		if alias is None:  alias = clc.Account.GetAlias()
		r = clc.API.v1_call('post','User/GetUsers',{'AccountAlias': alias})
		if int(r['StatusCode']) == 0:  
			return(r['Users'])


	@staticmethod
	def DeleteUser(user):
		r = clc.API.v1_call('post','User/DeleteUser',{'UserName': user})


	@staticmethod
	def SuspendUser(user):
		r = clc.API.v1_call('post','User/SuspendUser',{'UserName': user})


	@staticmethod
	def UnsuspendUser(user):
		r = clc.API.v1_call('post','User/UnsuspendUser',{'UserName': user})


	@staticmethod
	def CreateUser(alias, user, email, first_name, last_name, roles):
		if alias is None:  alias = clc.Account.GetAlias()
		payload = {'AccountAlias': alias, 'Roles': [] }
		if user is not None:  payload['UserName'] = user
		if email is not None:  payload['EmailAddress'] = email
		if first_name is not None:  payload['FirstName'] = first_name
		if last_name is not None:  payload['LastName'] = last_name
		if roles is not None:
			role_mapping = { 'Server': 2, 'Domain': 8, 'Account': 9 }
			for role in roles:  payload['Roles'].append(role_mapping[role])
		r = clc.API.v1_call('post','User/CreateUser',payload)
		if int(r['StatusCode']) == 0:  
			return(r['UserDetails'])


	@staticmethod
	def UpdateUser(alias, user, email, first_name, last_name, roles):
		if alias is None:  alias = clc.Account.GetAlias()
		payload = {'AccountAlias': alias, 'Roles': [] }
		if user is not None:  payload['UserName'] = user
		if email is not None:  payload['EmailAddress'] = email
		if first_name is not None:  payload['FirstName'] = first_name
		if last_name is not None:  payload['LastName'] = last_name
		if roles is not None:
			role_mapping = { 'Server': 2, 'Domain': 8, 'Account': 9 }
			for role in roles:  payload['Roles'].append(role_mapping[role])
		r = clc.API.v1_call('post','User/UpdateUser',payload)
		if int(r['StatusCode']) == 0:  
			return(r['UserDetails'])



