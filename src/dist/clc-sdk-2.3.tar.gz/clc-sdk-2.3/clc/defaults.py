
ENDPOINT_URL_V1 = "https://api.tier3.com/REST/"
ENDPOINT_URL_V2 = "https://api.tier3.com"

