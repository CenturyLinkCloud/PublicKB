#!/bin/bash

# Take parameters from command line
USERNAME="$1"
PASSWORD="$2"
ACCOUNT="$3"    # Example: BRYF
SERVERID="$4"   # Example: WA1BRYF2NDSRV01
FILENAME="$5"

# Names of value keys to get from JSON responses
TOKENKEY="bearerToken"
DCKEY="locationId"

# Build JSON for authorization request
AUTHJSON="{\"username\":\"$USERNAME\",\"password\":\"$PASSWORD\"}"

# Store URLs for API requests
BASEURL="https://api.tier3.com/v2"
AUTHURL="$BASEURL/authentication/login"
GETSRVURL="$BASEURL/servers/$ACCOUNT/$SERVERID"

# Simple helper function to parse JSON response ($1) and return value for given key ($2)
jsonGetVal() {
   echo $1 | sed 's/[{}]//g' | awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' | sed 's/\"//g' | grep $2 | awk 'BEGIN { FS = ":" } ; {print $2}'
}

# Call to authentication API to get token
AUTHRESP=`curl -s -H "Content-Type: application/json" -d $AUTHJSON $AUTHURL`
TOKEN=`jsonGetVal $AUTHRESP $TOKENKEY`

# Call to server API to get data center id for given server id
SRVRESP=`curl -s -H "Authorization: Bearer $TOKEN" $GETSRVURL`
DCID=`jsonGetVal "$SRVRESP" $DCKEY`

# Call to DC API to get data center name for given ID
GETDCURL="$BASEURL/datacenters/$ACCOUNT/$DCID"
DCRESP=`curl -s -H "Authorization: Bearer $TOKEN" $GETDCURL`
DCNAME=`jsonGetVal "$DCRESP" name`

# Write information to given file name
echo -e "$DCID\n$DCNAME" > $FILENAME