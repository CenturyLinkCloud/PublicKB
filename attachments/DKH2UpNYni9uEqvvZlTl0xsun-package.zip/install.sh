#!/bin/bash

# Take parameters from command line
ACTION="$1"    # Either "clone" or "pull" depending on first time deployment or update
GITREPO="$2"   # The URI for the repository
APPPATH="$3"   # The path on the server to deploy to

# Ensure git is installed
yum -y install git

if [ "$ACTION" = "clone" ] ; then 
   git clone "$GITREPO" "$APPPATH"
elif [ "$ACTION" = "pull" ] ; then
   cd "$APPPATH"
   git pull
fi
