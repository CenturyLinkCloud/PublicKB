Import-Module ServerManager
Install-WindowsFeature -Name Web-WebServer -IncludeManagementTools