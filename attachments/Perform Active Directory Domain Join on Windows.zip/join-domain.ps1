$user = $args[0]
$password = ConvertTo-SecureString $args[1] -AsPlainText -Force
$DomainName = $args[2] 
$credential = New-Object System.Management.Automation.PSCredential $DomainName\$user, $password

Add-Computer  -DomainName $args[3] -Credential $credential