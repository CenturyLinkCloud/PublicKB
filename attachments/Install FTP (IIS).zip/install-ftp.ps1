Import-Module ServerManager
Install-WindowsFeature -Name Web-Ftp-Server -IncludeManagementTools -IncludeAllSubFeature