﻿$ipAddress = $args[0]
$domainName = $args[1]
$pass = $args[2]

Import-Module ServerManager
Add-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools
Add-WindowsFeature -Name DNS -IncludeManagementTools

$safepass = ConvertTo-SecureString -AsPlainText -String $pass -Force
Install-ADDSForest -DomainName $domainName -DomainMode Win2012 -ForestMode Win2012 -SafeModeAdministratorPassword $safepass -SysVolPath C:\Windows\SYSVOL -DatabasePath C:\Windows\NTDS -LogPath C:\Windows\NTDS -InstallDNS -Force